$(document).ready(function() {
 /* AGREGANDO CLASE ACTIVE AL PRIMERO */
 $('.category_list .category_Item[category="all"]').addClass('ct_item-active');


 //FILTRANDO PRODUCTOS

 $('.category_Item').click(function(){
    //VARIABLES
    var catProduct = $(this).attr('category');
    console.log(catProduct);
    
    //AGREGANDO CLASE ACTIVE AL ENLACE SELECCIONADO
    $('.category_Item').removeClass('ct_item-active');
    $(this).addClass('ct_item-active');

    //OCULTANDO PRODUCTOS
    $('.product-item').css('transform', 'scale(0)');
    function hideProduct(){
        $('.product-item').hide();
    } setTimeout(hideProduct,400);


    //MOSTRAR PRODUCTOS
    function showProduct(){
        $('.product-item[category="'+catProduct+'"]').show();
        $('.product-item[category="'+catProduct+'"]').css('transform', 'scale(1)');
    } setTimeout(showProduct,400);
    
});
    //MOSTRANDO TODOS LOS PRODUCTOS
    $('.category_Item[category="all"]').click(function(){
    function showAll(){
    $('.product-item').show();
    $('.product-item').css('transform', 'scale(1)');
    }setTimeout(showAll,400);
});
});
